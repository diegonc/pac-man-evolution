#include <iostream>
#include "../common/client_socket.h"

int main(int argc, char **argv){
   Socket_Cliente e;
   
   std::cout << "Bueno, funciono algo!\n";
   
   return 0;
}
